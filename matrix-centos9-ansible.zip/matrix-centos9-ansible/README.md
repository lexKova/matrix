# Matrix / Xray / Nginx / Coturn — CentOS Stream 9

## Topology

- Public TCP/443 is published only by the Xray container.
- Xray REALITY fallback goes to internal Nginx :8443, which returns 404.
- The Xray routing rule sends requests for `matrix_domain` to internal Nginx :8444.
- Nginx routes `/_matrix` and `/_synapse/client` to Synapse; other paths go to Element.
- Synapse and PostgreSQL are reachable only on the Docker network.
- Coturn uses host networking, matching the old Compose design.

## Important caveats

1. This starter is a **private/non-federated** deployment. The Synapse listener exposes client resources only. Do not enable federation without redesigning how remote homeservers reach federation endpoints.
2. TURN is independent of Xray. `network_mode: host` only shares the host network namespace; it does not magically tunnel TURN through TCP/443. For TURN relay, clients must be able to reach UDP/TCP 3478 and the configured UDP relay range. Set `open_turn_firewall: true` to open those firewalld ports. If the cloud provider has a separate security group/firewall, open the same ports there too.
3. With only TCP/443 + SSH open, TURN relay is not guaranteed. Calls may still work peer-to-peer without TURN, depending on NAT conditions.
4. The `turn_uris` currently use the Matrix domain. That hostname must resolve for clients to the public address of this Coturn host. If it does not, create a dedicated `turn_domain` and adjust both Synapse and DNS.
5. A publicly trusted TLS certificate for `matrix_domain` is required. Put certificate and key in `files/certs/fullchain.pem` and `files/certs/privkey.pem`. Use ACME DNS-01 if inbound TCP/80 is unavailable. The certificate is used by internal Nginx; the client must trust it.
6. This is a test baseline. Verify that your Xray client preserves the Matrix hostname/SNI and routes `matrix_domain` through the VLESS tunnel. The Xray routing uses TLS/HTTP sniffing; ordinary direct browser access will not reach the internal Nginx.
7. Secrets in the previous chat were exposed. Generate new secrets and store `group_vars/all.yml` with Ansible Vault.
8. Image tags are pinned to the versions from the discussion; validate that your registry contains them. The `teddysun/xray` image config path/entrypoint should be verified against the exact image tag you use.

## Prepare controller

```bash
cp group_vars/all.yml.example group_vars/all.yml
```

Edit `group_vars/all.yml`. Generate UUID and REALITY keys with Xray tools:
```bash
xray uuid
xray x25519
```
Use a password manager or `openssl rand -hex 32` for each secret. Do not use the same secret for different purposes.

Place certificate files:
- `files/certs/fullchain.pem`
- `files/certs/privkey.pem`

Encrypt secrets:
```bash
ansible-vault encrypt group_vars/all.yml
```

Install collections and deploy:
```bash
ansible-galaxy collection install -r requirements.yml
ansible-playbook playbook.yml --ask-vault-pass
```

## Verify on server

```bash
docker compose -f /opt/matrix/docker-compose.yml ps
docker logs xray
docker logs matrix-proxy
docker logs synapse
docker logs coturn
ss -lntup
firewall-cmd --list-all
```

Expected public Docker-published port: TCP/443 only. Coturn host-network sockets appear separately when Coturn starts.

## Create first user

```bash
docker exec -it synapse register_new_matrix_user \
  -c /data/homeserver.yaml \
  http://127.0.0.1:8008
```
Add `--admin` to create an administrator.

## Client configuration

Client needs:
- VLESS UUID = `xray_uuid`
- server address = your server public IP / domain
- port = `443`
- flow = `xtls-rprx-vision`
- network = TCP
- security = REALITY
- serverName = `xray_reality_server_name`
- public key derived from `xray_reality_private_key`
- short ID = `xray_reality_short_id`

Route the Matrix domain through the VLESS outbound. Ensure DNS/SNI for `matrix_domain` is preserved through the proxy.
